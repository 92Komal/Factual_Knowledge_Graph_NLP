---
name: "\U0001F31F New adapter setup or model"
about: Submit a proposal/request to implement a new adapter setup or to add adapters to a new model
title: ''
labels: 'enhancement'
assignees: ''

---

# 🌟 New adapter setup

## Model description

<!-- Important information -->

## Open source status

* [ ] the model implementation is available: (give details)
* [ ] the model weights are available: (give details)
* [ ] who are the authors: (mention them, if possible by @gh-username)
