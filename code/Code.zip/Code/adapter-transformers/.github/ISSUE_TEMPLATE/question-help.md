---
name: "❓ Questions & Help"
about: Submit a question on working with adapter-transformers or a request for help
title: ''
labels: 'question'
assignees: ''
---


## Environment info
<!-- You can run the command `transformers-cli env` and copy-and-paste its output below.
     Remove if your question/ request is not technical. -->
     
- `adapter-transformers` version:
- Platform:
- Python version:
- PyTorch version (GPU?):

## Details

<!-- Additional details -->
