Model Adapters Config
=======================

This class manages the setup and configuration of adapter modules in a pre-trained model.

.. autoclass:: transformers.ModelAdaptersConfig
    :members:
