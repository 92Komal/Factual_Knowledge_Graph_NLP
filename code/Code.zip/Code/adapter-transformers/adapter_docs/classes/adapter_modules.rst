Adapter Modules
===============

Classes implementing task and language adapters.

.. automodule:: transformers.adapter_modeling
    :members:
