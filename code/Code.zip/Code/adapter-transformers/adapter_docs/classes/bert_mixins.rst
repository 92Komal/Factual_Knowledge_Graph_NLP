BERT Mixins
====================

These classes added to the BERT module classes add support for adapters to all BERT-based transformer models.

.. automodule:: transformers.adapter_bert
    :members:
